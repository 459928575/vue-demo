export default {
    // 表格头部样式设置
    headerCellStyle: {
        background: '#F7F7F7'
    },
    drawerWith: 500
}