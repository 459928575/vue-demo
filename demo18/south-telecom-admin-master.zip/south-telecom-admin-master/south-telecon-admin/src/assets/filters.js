let stringtoNumber = value => Number(value)
export {
    stringtoNumber
}